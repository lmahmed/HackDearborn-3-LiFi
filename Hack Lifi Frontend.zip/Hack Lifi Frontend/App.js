import React from 'react';
import LED from './LED';

function App() {
  return (
    <div className="App">
      <header className="Hack Lifi">
        <LED />
      </header>
    </div>
  );
}

export default App;
